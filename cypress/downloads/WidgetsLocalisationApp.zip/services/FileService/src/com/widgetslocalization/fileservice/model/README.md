Create your model classes in this package.

# 🚀 Migration Report

## 📌 Version: 11.9

- Updated ui-build.js and build.xml files


- Migrated authProviders configuration from map to list format in auth-info.json file


- Added default wizard action markup for existing wm-wizard widget in `1` Page(s)


- Added languageBundleSources and serviceDefSources property with value as STATIC in .wmproject.properties
- Added app.apiUrl property in app.properties and made it configurable from all profile property files with empty value as default


- Deleted Dockerfile.build file
- Updated Dockerfile which simplifies WaveMaker App Docker Image creation



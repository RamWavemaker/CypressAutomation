# 🚀 Migration Report

## 📌 Version: 11.10

- Updated ui-build.js file with fixes supporting concurrent builds


- Updated apache http logger package from org.apache.http.client to org.apache.hc.client5 in log4j2.xml


- Updated optimizeUIBuild default value to false in build.xml file


## 📌 Version: 11.9

- Updated ui-build.js and build.xml files


- Migrated authProviders configuration from map to list format in auth-info.json file


- Added default wizard action markup for existing wm-wizard widget in `1` Page(s)


- Added languageBundleSources and serviceDefSources property with value as STATIC in .wmproject.properties
- Added app.apiUrl property in app.properties and made it configurable from all profile property files with empty value as default


- Deleted Dockerfile.build file
- Updated Dockerfile which simplifies WaveMaker App Docker Image creation



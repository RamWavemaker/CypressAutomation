export default {
    baseFont: '',
    fonts: [
        /**
         * {
         *  name: fontName,
         *  path: 'relative (from webapp) path of font files in webapp folder.'
         * }
         */
    ]
};

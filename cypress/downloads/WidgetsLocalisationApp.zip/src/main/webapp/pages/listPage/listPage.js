/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.AllTypesList1Click = function ($event, widget) {
    Page.Widgets.label24_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesList1Dblclick = function ($event, widget) {
    Page.Widgets.label25_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesList1Mouseenter = function ($event, widget) {
    Page.Widgets.label26_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesList1Mouseleave = function ($event, widget) {
    Page.Widgets.label27_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesList1Select = function (widget, $data) {
    Page.Widgets.label28_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesList1Beforedatarender = function (widget, $data) {
    Page.Widgets.label34.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesList1Render = function (widget, $data) {
    Page.Widgets.label35.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesList1Paginationchange = function ($event, widget, $index) {
    Page.Widgets.label36.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesList1Setrecord = function ($event, widget, $index, $data) {
    Page.Widgets.label37.caption = App.getDependency('i18nService').messages['A_SuccessType']
};

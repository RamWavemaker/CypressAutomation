/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.panel1Mouseover = function ($event, widget) {
    Page.Widgets.label10.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.panel1Mouseout = function ($event, widget) {
    Page.Widgets.label11.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.panel1Mouseenter = function ($event, widget) {
    Page.Widgets.label12.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.panel1Mouseleave = function ($event, widget) {
    Page.Widgets.label13.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};

Page.panel1Close = function ($event, widget) {
    debugger
    Page.Widgets.label18.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.panel1Expand = function ($event, widget) {
    debugger
    Page.Widgets.label19.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.panel1Collapse = function ($event, widget) {
    debugger
    Page.Widgets.label21.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.panel1Actionsclick = function ($item) {
    Page.Widgets.label22.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.panel1Fullscreen = function ($event, widget) {
    Page.Widgets.label23.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.panel1Exitfullscreen = function ($event, widget) {
    Page.Widgets.label20.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};

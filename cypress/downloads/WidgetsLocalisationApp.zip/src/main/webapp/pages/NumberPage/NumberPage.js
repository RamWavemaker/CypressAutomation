/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};


Page.number5Click = function ($event, widget) {
    Page.Widgets.number5.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']
};
Page.number6Mouseenter = function ($event, widget) {
    Page.Widgets.number6.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']
};
Page.number7Mouseleave = function ($event, widget) {
    Page.Widgets.number7.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
Page.number8Tap = function ($event, widget) {
    Page.Widgets.number8.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
Page.number9Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.number9.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
Page.number11Focus = function ($event, widget) {
    Page.Widgets.number11.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
Page.number12Blur = function ($event, widget) {
    Page.Widgets.number12.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
Page.number19_1Keyup = function ($event, widget) {
    debugger;
    Page.Widgets.number19_1.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
Page.number20_1Keydown = function ($event, widget) {
    debugger;
    Page.Widgets.number20_1.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
Page.number21Keypress = function ($event, widget) {
    Page.Widgets.number21.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};

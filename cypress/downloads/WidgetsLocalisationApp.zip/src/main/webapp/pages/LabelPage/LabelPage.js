/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};

Page.label20Dblclick = function ($event, widget) {
    Page.Widgets.label20.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.label21Mouseenter = function ($event, widget) {
    Page.Widgets.label21.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.label32_1Tap = function ($event, widget) {
    Page.Widgets.label32_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.label33Doubletap = function ($event, widget) {
    Page.Widgets.label33.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.label22Mouseleave = function ($event, widget) {
    Page.Widgets.label22.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.label19Click = function ($event, widget) {
    Page.Widgets.label19.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.label34Doubletap = function ($event, widget) {
    Page.Widgets.label34.caption = App.getDependency('i18nService').messages['A_SuccessType']
};

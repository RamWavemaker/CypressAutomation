/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.carousel1Change = function (widget, newIndex, oldIndex) {
    Page.Widgets.label5.caption = App.getDependency('i18nService').messages['A_SuccessType'];

    /*
    * newIndex: index of the active carousel in view 
                * oldIndex: index of the previous carousel in view 
                * Note: In case carousels are rendered dynamically through binding dataSet, use following properties to access carousel data objects:
                *   -widget.currentslide: data object against the active carousel in view 
                *   -widget.previousslide: data object against the previous carousel in view
    */
};

//picture 1 events

Page.picture1Click = function ($event, widget) {
    Page.Widgets.label7.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.picture1Dblclick = function ($event, widget) {
    Page.Widgets.label9.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.picture1Mouseenter = function ($event, widget) {
    Page.Widgets.label11.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.picture1Mouseleave = function ($event, widget) {
    Page.Widgets.label13.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.picture1Tap = function ($event, widget) {
    Page.Widgets.label15.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.picture1Doubletap = function ($event, widget) {
    Page.Widgets.label17.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};

//picture 2 events
Page.picture2Click = function ($event, widget) {
    Page.Widgets.label19.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.picture2Dblclick = function ($event, widget) {
    Page.Widgets.label21.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.picture2Mouseenter = function ($event, widget) {
    Page.Widgets.label23.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.picture2Mouseleave = function ($event, widget) {
    Page.Widgets.label25.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.picture2Tap = function ($event, widget) {
    Page.Widgets.label27.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.picture2Doubletap = function ($event, widget) {
    Page.Widgets.label29.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};

/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};


Page.checkbox5Click = function ($event, widget) {
    debugger;
    Page.Widgets.checkbox5.caption = App.getDependency('i18nService').messages['A_Hello'];
};
Page.checkbox6Mouseenter = function ($event, widget) {
    debugger;
    Page.Widgets.checkbox6.caption = App.getDependency('i18nService').messages['A_Hello'];
};
Page.checkbox7Mouseleave = function ($event, widget) {
    debugger;
    Page.Widgets.checkbox7.caption = App.getDependency('i18nService').messages['A_Hello'];
};
Page.checkbox8Tap = function ($event, widget) {
    debugger;
    Page.Widgets.checkbox8.caption = App.getDependency('i18nService').messages['A_Hello'];
};
Page.checkbox9Change = function ($event, widget, newVal, oldVal) {
    debugger;
    Page.Widgets.checkbox9.caption = App.getDependency('i18nService').messages['A_Hello'];
};
Page.checkbox10Focus = function ($event, widget) {
    debugger;
    Page.Widgets.checkbox10.caption = App.getDependency('i18nService').messages['A_Hello'];
};
Page.checkbox11Blur = function ($event, widget) {
    debugger;
    Page.Widgets.checkbox11.caption = App.getDependency('i18nService').messages['A_Hello'];
};

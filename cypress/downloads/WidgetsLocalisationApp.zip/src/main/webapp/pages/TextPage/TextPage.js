/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};

Page.text9Click = function ($event, widget) {
    Page.Widgets.text9.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.text10Mouseenter = function ($event, widget) {
    Page.Widgets.text10.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.text11Mouseleave = function ($event, widget) {
    Page.Widgets.text11.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.text12Tap = function ($event, widget) {
    Page.Widgets.text12.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.text14Focus = function ($event, widget) {
    Page.Widgets.text14.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.text15Blur = function ($event, widget) {
    Page.Widgets.text15.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.text16Keyup = function ($event, widget) {
    Page.Widgets.text16.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.text17Keydown = function ($event, widget) {
    Page.Widgets.text17.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.text18Keypress = function ($event, widget) {
    Page.Widgets.text18.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
// Page.text23Change = function ($event, widget, newVal, oldVal) {
//     debugger;
//     Page.Widgets.text23.placeholder = App.getDependency('i18nService').messages['A_Hello']

// };
Page.text13Change = function ($event, widget, newVal, oldVal) {
    debugger;
    Page.Widgets.text13.placeholder = App.getDependency('i18nService').messages['A_Hello']

};

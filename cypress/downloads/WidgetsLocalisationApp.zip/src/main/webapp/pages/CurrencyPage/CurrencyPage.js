/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};

Page.currency7Click = function ($event, widget) {
    Page.Widgets.currency7.placeholder = App.getDependency('i18nService').messages['A_Hello']
};
Page.currency8Mouseenter = function ($event, widget) {
    Page.Widgets.currency8.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.currency10Mouseleave = function ($event, widget) {
    Page.Widgets.currency10.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.currency12Tap = function ($event, widget) {
    Page.Widgets.currency12.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.currency17Focus = function ($event, widget) {
    Page.Widgets.currency17.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.currency15Blur = function ($event, widget) {
    Page.Widgets.currency15.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.currency13Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.currency13.placeholder = App.getDependency('i18nService').messages['A_Hello']
};

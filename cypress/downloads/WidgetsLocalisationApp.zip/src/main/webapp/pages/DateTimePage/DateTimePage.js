/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};



Page.datetime5Click = function ($event, widget) {
    Page.Widgets.datetime5.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.datetime6Mouseenter = function ($event, widget) {
    Page.Widgets.datetime6.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.datetime7Mouseleave = function ($event, widget) {
    Page.Widgets.datetime7.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.datetime8Tap = function ($event, widget) {
    Page.Widgets.datetime8.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.datetime9Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.datetime9.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.datetime10Focus = function ($event, widget) {
    Page.Widgets.datetime10.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.datetime11Blur = function ($event, widget) {
    Page.Widgets.datetime11.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.datetime12Beforeload = function ($event, widget) {
    Page.Widgets.datetime12.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};

/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};

Page.switch3Click = function ($event, widget) {
    Page.Widgets.label41.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.switch4Mouseenter = function ($event, widget) {
    Page.Widgets.label42_1.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.switch5Mouseleave = function ($event, widget) {
    Page.Widgets.label43.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.switch6Tap = function ($event, widget) {
    Page.Widgets.label44.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.switch7Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.label45.caption = App.getDependency('i18nService').messages['A_Hello']
};

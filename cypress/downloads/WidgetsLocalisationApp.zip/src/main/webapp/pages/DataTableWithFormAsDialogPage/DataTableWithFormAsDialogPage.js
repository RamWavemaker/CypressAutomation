/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.EmployeeTable1Rowclick = function ($event, widget, row) {
    //Changing caption of a label with applocale key value.
    Page.Widgets.label5.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.EmployeeTable1Sort = function ($event, widget, $data) {
    Page.Widgets.label6.caption = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.EmployeeTable1Beforerowdelete = function ($event, widget, row, options) {
    Page.Widgets.label7.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.EmployeeTable1Datarender = function (widget, data) {
    Page.Widgets.label9.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.EmployeeTable1Setrecord = function ($event, widget, data, pageInfo) {
    Page.Widgets.label9_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.EmployeeTable1Rowselect = function ($event, widget, row) {
    Page.Widgets.label12.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.EmployeeTable1Rowdeselect = function ($event, widget, row) {
    Page.Widgets.label13.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.EmployeeTable1Headerclick = function ($event, widget, column) {
    Page.Widgets.label14.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.EmployeeTable1Beforedatarender = function (widget, data, columns) {
    Page.Widgets.label15_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.EmployeeTable1Beforefilter = function (widget, columns) {
    Page.Widgets.label16.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.EmployeeTable1Rowdelete = function ($event, widget, row) {
    Page.Widgets.label15.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.EmployeeTable1Beforefilter = function (widget, columns) {
    Page.Widgets.label35.caption = App.getDependency('i18nService').messages['A_SuccessType']
};

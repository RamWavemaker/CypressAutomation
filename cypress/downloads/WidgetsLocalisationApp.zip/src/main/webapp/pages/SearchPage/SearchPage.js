/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.search5Submit = function ($event, widget) {
    Page.Widgets.label15.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.search5Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.label54.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.search5Focus = function ($event, widget) {
    Page.Widgets.label55.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.search5Blur = function ($event, widget) {
    Page.Widgets.label56.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.search5Select = function ($event, widget, selectedValue) {
    Page.Widgets.label50.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.search5Beforeservicecall = function (widget, inputData) {
    Page.Widgets.label51.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.search5Datasetready = function (widget, data) {
    Page.Widgets.label52.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.search5Clear = function ($event, widget) {
    Page.Widgets.label53.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};

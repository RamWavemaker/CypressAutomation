/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};

Page.fileupload28Beforeselect = function ($event, widget, files) {
    Page.Widgets.fileupload28.caption = App.getDependency('i18nService').messages['A_SuccessType'];

};
Page.fileupload27Select = function ($event, widget, selectedFiles) {
    Page.Widgets.fileupload27.caption = App.getDependency('i18nService').messages['A_SuccessType'];

};
Page.fileupload29Error = function ($event, widget, files) {
    Page.Widgets.fileupload29.caption = App.getDependency('i18nService').messages['A_SuccessType'];

};
Page.fileupload30Beforedelete = function ($event, widget) {
    Page.Widgets.fileupload30.caption = App.getDependency('i18nService').messages['A_SuccessType'];

};
Page.fileupload31Delete = function ($event, widget) {
    Page.Widgets.fileupload31.caption = App.getDependency('i18nService').messages['A_SuccessType'];

};

/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.tile1Click = function ($event, widget) {
    Page.Widgets.label6.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Dblclick = function ($event, widget) {
    Page.Widgets.label7.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Mouseover = function ($event, widget) {
    Page.Widgets.label9.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Mouseout = function ($event, widget) {
    Page.Widgets.label11.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Mouseenter = function ($event, widget) {
    Page.Widgets.label13.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Mouseleave = function ($event, widget) {
    Page.Widgets.label16.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};

//tap events
Page.tile1Tap = function ($event, widget) {
    Page.Widgets.label23.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Doubletap = function ($event, widget) {
    Page.Widgets.label24.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Touchstart = function ($event, widget) {
    Page.Widgets.label25.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Touchend = function ($event, widget) {
    Page.Widgets.label26.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Swipeup = function ($event, widget) {
    Page.Widgets.label27.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Swipedown = function ($event, widget) {
    Page.Widgets.label34.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Swipeleft = function ($event, widget) {
    Page.Widgets.label35.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Swiperight = function ($event, widget) {
    Page.Widgets.label36.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Pinchin = function ($event, widget) {
    Page.Widgets.label37.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.tile1Pinchout = function ($event, widget) {
    Page.Widgets.label38.caption = App.getDependency('i18nService').messages['A_SuccessType'];
};

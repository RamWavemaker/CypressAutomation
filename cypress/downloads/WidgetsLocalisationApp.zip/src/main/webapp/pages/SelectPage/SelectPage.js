/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};



Page.select5Click = function ($event, widget) {
    Page.Widgets.select5.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.select6Mouseenter = function ($event, widget) {
    Page.Widgets.select6.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.select7Mouseleave = function ($event, widget) {
    Page.Widgets.select7.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.select8Tap = function ($event, widget) {
    Page.Widgets.select8.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.select9Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.select9.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.select10Focus = function ($event, widget) {
    Page.Widgets.select10.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.select11Blur = function ($event, widget) {
    Page.Widgets.select11.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.select12Keyup = function ($event, widget) {
    debugger;
    Page.Widgets.select12.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.select13Keydown = function ($event, widget) {
    debugger;
    Page.Widgets.select13.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.select14Keypress = function ($event, widget) {
    debugger;
    Page.Widgets.select14.placeholder = App.getDependency('i18nService').messages['A_Hello']

};


Page.custom1Keydown = function ($event, widget) {
    debugger;
};

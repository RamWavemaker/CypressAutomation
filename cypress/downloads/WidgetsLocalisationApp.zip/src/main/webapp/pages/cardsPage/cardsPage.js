/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.EmployeeList1Click = function ($event, widget) {
    Page.Widgets.label16.caption = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.EmployeeList1Dblclick = function ($event, widget) {
    Page.Widgets.label17.caption = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.EmployeeList1Mouseenter = function ($event, widget) {
    Page.Widgets.label19.caption = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.EmployeeList1Mouseleave = function ($event, widget) {
    Page.Widgets.label18.caption = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.EmployeeList1Select = function (widget, $data) {
    Page.Widgets.label31.caption = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.EmployeeList1Beforedatarender = function (widget, $data) {
    Page.Widgets.label33.caption = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.EmployeeList1Render = function (widget, $data) {
    Page.Widgets.label34.caption = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.EmployeeList1Paginationchange = function ($event, widget, $index) {
    Page.Widgets.label35.caption = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.EmployeeList1Setrecord = function ($event, widget, $index, $data) {
    Page.Widgets.label37.caption = App.getDependency('i18nService').messages['A_SuccessType']

};

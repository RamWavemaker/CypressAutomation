/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};



Page.textarea5Click = function ($event, widget) {
    Page.Widgets.textarea5.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.textarea6Click = function ($event, widget) {
    Page.Widgets.textarea6.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.textarea7Mouseleave = function ($event, widget) {
    Page.Widgets.textarea7.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.textarea8Tap = function ($event, widget) {
    Page.Widgets.textarea8.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.textarea9Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.textarea9.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.textarea10Focus = function ($event, widget) {
    Page.Widgets.textarea10.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.textarea11Blur = function ($event, widget) {
    Page.Widgets.textarea11.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.textarea12Keyup = function ($event, widget) {
    Page.Widgets.textarea12.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.textarea13Keydown = function ($event, widget) {
    Page.Widgets.textarea13.placeholder = App.getDependency('i18nService').messages['A_Hello']

};
Page.textarea14Keypress = function ($event, widget) {
    Page.Widgets.textarea14.placeholder = App.getDependency('i18nService').messages['A_Hello']

};

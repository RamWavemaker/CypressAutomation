/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.chips4Chipclick = function ($event, widget, $item) {
    Page.Widgets.chips4.placeholder = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.chips5Beforeadd = function ($event, widget, newItem) {
    Page.Widgets.chips5.placeholder = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.chips6Beforeremove = function ($event, widget, $item) {
    Page.Widgets.chips6.placeholder = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.chips7Add = function ($event, widget, $item) {
    Page.Widgets.chips7.placeholder = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.chips8Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.chips8.placeholder = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.chips9Remove = function ($event, widget, $item) {
    Page.Widgets.chips9.placeholder = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.chips10Chipselect = function ($event, widget, $item) {
    Page.Widgets.chips10.placeholder = App.getDependency('i18nService').messages['A_SuccessType'];
};
Page.chips11Beforeservicecall = function (widget, inputData) {
    Page.Widgets.chips11.placeholder = App.getDependency('i18nService').messages['A_SuccessType'];
};

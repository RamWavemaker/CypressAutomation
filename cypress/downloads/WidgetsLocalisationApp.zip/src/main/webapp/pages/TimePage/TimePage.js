/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};




Page.time5Click = function ($event, widget) {
    Page.Widgets.time5.placeholder = App.getDependency('i18nService').messages['A_SuccessType'];

};
Page.time6Mouseenter = function ($event, widget) {
    Page.Widgets.time6.placeholder = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.time7Mouseleave = function ($event, widget) {
    Page.Widgets.time7.placeholder = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.time8Tap = function ($event, widget) {
    Page.Widgets.time8.placeholder = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.time9Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.time9.placeholder = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.time10Focus = function ($event, widget) {
    Page.Widgets.time10.placeholder = App.getDependency('i18nService').messages['A_SuccessType']

};

Page.time11Blur = function ($event, widget) {
    Page.Widgets.time11.placeholder = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.time12Beforeload = function ($event, widget) {
    debugger;
    Page.Widgets.time12.placeholder = App.getDependency('i18nService').messages['A_SuccessType']
    console.log(Page.Widgets.time12.placeholder);


};

/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};

Page.toggle5Click = function ($event, widget) {
    Page.Widgets.label59_1.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.toggle6Mouseenter = function ($event, widget) {
    Page.Widgets.label60_1.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.toggle7Mouseleave = function ($event, widget) {
    Page.Widgets.label61_1.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.toggle8Tap = function ($event, widget) {
    Page.Widgets.label62_1.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.toggle9Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.label63.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.toggle10Focus = function ($event, widget) {
    Page.Widgets.label64.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.toggle12Blur = function ($event, widget) {
    Page.Widgets.label66.caption = App.getDependency('i18nService').messages['A_Hello']

};

/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.anchor7Click = function ($event, widget) {
    Page.Widgets.label14.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.anchor8Dblclick = function ($event, widget) {
    Page.Widgets.label16_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.anchor9Mouseenter = function ($event, widget) {
    Page.Widgets.label17.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.anchor10Mouseleave = function ($event, widget) {
    Page.Widgets.label18.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.anchor11Tap = function ($event, widget) {
    Page.Widgets.label19.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.anchor12Doubletap = function ($event, widget) {
    Page.Widgets.label20.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.anchor10_1Focus = function ($event, widget) {
    Page.Widgets.label19_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.anchor11_1Blur = function ($event, widget) {
    Page.Widgets.label21.caption = App.getDependency('i18nService').messages['A_SuccessType']
};

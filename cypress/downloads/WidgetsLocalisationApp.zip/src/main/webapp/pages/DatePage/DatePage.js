/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};



Page.date5Click = function ($event, widget) {
    Page.Widgets.date5.placeholder = App.getDependency('i18nService').messages['A_Entervalue']
};
Page.date6Mouseenter = function ($event, widget) {
    Page.Widgets.date6.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.date7Mouseleave = function ($event, widget) {
    Page.Widgets.date7.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.date8Tap = function ($event, widget) {
    Page.Widgets.date8.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.date9Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.date9.placeholder = App.getDependency('i18nService').messages['A_Entervalue']
};

Page.date10Focus = function ($event, widget) {
    debugger;
    Page.Widgets.date10.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.date11Blur = function ($event, widget) {
    Page.Widgets.date11.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};
Page.date12Beforeload = function ($event, widget) {
    Page.Widgets.date12.placeholder = App.getDependency('i18nService').messages['A_Entervalue']

};

/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.AllTypesTable1Rowclick = function ($event, widget, row) {
    Page.Widgets.label5.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesTable1Sort = function ($event, widget, $data) {
    Page.Widgets.label6.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesTable1Beforerowdelete = function ($event, widget, row, options) {
    Page.Widgets.label7.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesTable1Datarender = function (widget, data) {
    Page.Widgets.label9.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesTable1Setrecord = function ($event, widget, data, pageInfo) {
    Page.Widgets.label9_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesTable1Rowdelete = function ($event, widget, row) {
    Page.Widgets.label15.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AllTypesTable1Headerclick = function ($event, widget, column) {
    Page.Widgets.label14.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AccountTable1Rowselect = function ($event, widget, row) {
    Page.Widgets.label12.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AccountTable1Rowdeselect = function ($event, widget, row) {
    Page.Widgets.label13.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AccountTable1Beforedatarender = function (widget, data, columns) {
    Page.Widgets.label15_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};
Page.AccountTable1Beforefilter = function (widget, columns) {
    Page.Widgets.label16.caption = App.getDependency('i18nService').messages['A_SuccessType']

};
Page.AllTypesTable1Beforefilter = function (widget, columns) {
    Page.Widgets.label31_1.caption = App.getDependency('i18nService').messages['A_SuccessType']
};

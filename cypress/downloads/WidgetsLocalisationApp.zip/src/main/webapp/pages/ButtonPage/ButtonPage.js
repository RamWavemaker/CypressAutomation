/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.button17Click = function ($event, widget) {
    Page.Widgets.button17.caption = App.getDependency('i18nService').messages['A_Hello']
    //Page.Widgets.button1.caption = App.getDependency('i18nService').messages['Auto_boolean_demo']

};
Page.button19Dblclick = function ($event, widget) {
    Page.Widgets.button19.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.button18Mouseenter = function ($event, widget) {
    Page.Widgets.button18.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.button21Mouseleave = function ($event, widget) {
    Page.Widgets.button21.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.button20Tap = function ($event, widget) {
    Page.Widgets.button20.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.button22Doubletap = function ($event, widget) {
    Page.Widgets.button22.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.button23Keydown = function ($event, widget) {
    Page.Widgets.button23.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.button24Keypress = function ($event, widget) {
    Page.Widgets.button24.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.button23_1Keyup = function ($event, widget) {
    debugger;
    Page.Widgets.button23_1.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.button2Click = function ($event, widget) {
    Page.Widgets.button2.caption = "Resetbutton"
};
Page.button24_1Focus = function ($event, widget) {
    Page.Widgets.button24_1.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.button23_2Blur = function ($event, widget) {
    Page.Widgets.button23_2.caption = App.getDependency('i18nService').messages['A_Hello']

};

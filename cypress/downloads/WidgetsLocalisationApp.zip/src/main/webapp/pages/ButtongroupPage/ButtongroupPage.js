/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
// Page.button17Click = function ($event, widget) {
//     Page.Widgets.button17.caption = App.getDependency('i18nService').messages['A_hint']
//     //Page.Widgets.button1.caption = App.getDependency('i18nService').messages['Auto_boolean_demo']

// };

Page.button35Click = function ($event, widget) {
    Page.Widgets.button35.caption = App.getDependency('i18nService').messages['A_Hello']
};
Page.button38Dblclick = function ($event, widget) {
    Page.Widgets.button38.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.button41Mouseenter = function ($event, widget) {
    Page.Widgets.button41.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.button44Mouseleave = function ($event, widget) {
    Page.Widgets.button44.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.button47Tap = function ($event, widget) {
    Page.Widgets.button47.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.button50Doubletap = function ($event, widget) {
    Page.Widgets.button50.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.button53Keydown = function ($event, widget) {
    Page.Widgets.button53.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.button59Keypress = function ($event, widget) {
    Page.Widgets.button59.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.button56Keyup = function ($event, widget) {
    Page.Widgets.button56.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.button67_1Focus = function ($event, widget) {
    Page.Widgets.button67_1.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.button29_1Blur = function ($event, widget) {
    Page.Widgets.button29.caption = App.getDependency('i18nService').messages['A_Hello']

};
Page.button70_1Blur = function ($event, widget) {
    Page.Widgets.button70_1.caption = App.getDependency('i18nService').messages['A_Hello']

};

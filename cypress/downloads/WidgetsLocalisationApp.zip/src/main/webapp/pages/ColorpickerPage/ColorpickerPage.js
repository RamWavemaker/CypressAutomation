/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};


Page.colorpicker6Click = function ($event, widget) {
    Page.Widgets.colorpicker6.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']
};
Page.colorpicker7Mouseenter = function ($event, widget) {
    Page.Widgets.colorpicker7.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']
};
Page.colorpicker8Mouseleave = function ($event, widget) {
    Page.Widgets.colorpicker8.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
Page.colorpicker9Tap = function ($event, widget) {
    Page.Widgets.colorpicker9.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
Page.colorpicker10Change = function ($event, widget, newVal, oldVal) {
    Page.Widgets.colorpicker10.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
Page.colorpicker11Focus = function ($event, widget) {
    Page.Widgets.colorpicker11.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
Page.colorpicker12Blur = function ($event, widget) {
    Page.Widgets.colorpicker12.placeholder = App.getDependency('i18nService').messages['A_Badgevalue']

};
